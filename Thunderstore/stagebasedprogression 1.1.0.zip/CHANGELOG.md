## 1.1.0
- increased the difficulty gain by 1.5x

## 1.0.0
- First release