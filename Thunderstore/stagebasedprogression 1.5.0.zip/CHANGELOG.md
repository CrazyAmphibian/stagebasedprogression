## 1.5.0
- fixed ambient level cap not being respected correctly.
- the multiplayer playerfactor now applies to the initial difficulty.
- makes it consistent with how vanilla scaling works.
- increased exponential difficulty increase from 2.5% to 5%

## 1.4.1
- fixed the mod logging every frame with data

## 1.4.0
- fixed multiple players causing the ambient level to be negative
- reduced multiplayer scaling to use vanilla values. +.3x, from +.5x

## 1.3.0
- added an additional 1 and 1/4 block of difficulty (scales with difficulty scaling) to start out with.
- the intent is to make going into a map more difficult, to balance the fact that difficulty never increases while in a map.

## 1.2.0
- reduced the difficulty gain. each stage now nets 2.5 "blocks" per stage (down from 3)
- added an amount of exponential scaling. each stage cleared after the first now adds 2.5% more block

## 1.1.0
- increased the difficulty gain by 1.5x

## 1.0.0
- First release