# Stage Based Progression
a mod that changes the difficulty scaling formula in Risk of Rain 2 from time-based to stage-based.

## why?
because the time pressure stresses me out (especially when playing with others), but reducing the difficulty scaling makes the game piss easy, so instead i rewrote the scaling code.

## compatability
the mod is written in a way that should be compatible with \*most\* difficulties (depending on if they edit `RecalculateDifficultyCoefficent`). The mod will change the ambient level accordingly with scaling speed.
however, since this mod **completely overwrites** the default function, expect some issues with mods that do modify that function.

## the math?
this is the __default__ scaling function
```
playerfactor = 1 + 0.3*(playercount-1)
timefactor = 0.0506*difficultyscaling*(playercount^0.2)
stagefactor=1.15^stagescompleted

difficulty=(playerfactor + minutesingame * timefactor) * stagefactor
```

and this is this mod's scaling function
```
playerfactor= 1 + 0.5*(playercount-1)
stagefactor= difficultyscaling*(stagescompleted-1)

difficulty= 1+(stagefactor*playerfactor)
```

## effect on balance?
i'm not really sure what effect it'll have. the standard function scales exponentially with stages, but is also focused around time and not stages so...
it'll probably be easier if you take a lot of time per stage, but harder if you speedrun stages.
but this is just speculation